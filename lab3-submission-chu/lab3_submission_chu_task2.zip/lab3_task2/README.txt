I am in Activity A. When I click Dialog A, I pause and resume the activity.
 This is because the view is still present therefore the activity is still visible and existing.